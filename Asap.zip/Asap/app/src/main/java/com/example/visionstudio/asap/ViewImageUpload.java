package com.example.visionstudio.asap;

import android.app.Activity;
import android.os.Bundle;

public class ViewImageUpload extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_image_upload);
    }
}
