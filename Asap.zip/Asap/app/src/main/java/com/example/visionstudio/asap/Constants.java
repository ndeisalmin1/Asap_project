package com.example.visionstudio.asap;

public class Constants {
    public static final String UPLOAD_URL = "http://innutritious-entrie.000webhostapp.com/upload.php";
    //public static final String IMAGES_URL = "http://192.168.94.1/AndroidImageUpload/getImages.php";
}

