package com.example.visionstudio.asap;

public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http://innutritious-entrie.000webhostapp.com/login.php";

    // Server user register url
    public static String URL_REGISTER = "http://innutritious-entrie.000webhostapp.com/register.php";
}

